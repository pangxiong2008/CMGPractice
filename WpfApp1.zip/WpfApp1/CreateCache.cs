﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Caching;
using log4net;

namespace WpfApp1
{
    class CreateCache
    {
        private static log4net.ILog Log { get; } = LogManager.GetLogger(typeof(ReadData));
        public async Task<List<WellProductionDataModel>> CacheWellPro()
        {
            List<WellProductionDataModel > listWellPro =new List<WellProductionDataModel>();
            listWellPro.Clear();
            try
            {
                ObjectCache cache = MemoryCache.Default;
                var myCache = cache["WellProCache"] as List<WellProductionDataModel>;
                if (myCache == null)
                {
                    CacheItemPolicy policy = new CacheItemPolicy();
                    policy.AbsoluteExpiration = DateTime.Now.AddHours(1);
                    ReadData readData = new ReadData();
                   var  myCache1 =await  Task.Run<List<WellProductionDataModel>>(()=> readData.ImportData());
                  
                    listWellPro = myCache1;
                    cache.Set("WellProCache", myCache1, policy);
                }
            }
            catch (Exception ex)
            {
                listWellPro = null;
                Log.Error(ex);
            }
            return listWellPro;
        }
    }

    class ReadCache
    {
        private static log4net.ILog Log { get; } = LogManager.GetLogger(typeof(ReadData));
        public List<WellProductionDataModel> ReadWellPro()
        {
            CreateCache createCache = new CreateCache();
            createCache.CacheWellPro();
            ObjectCache cache = MemoryCache.Default;
            var WellProCache = cache["WellProCache"] as List<WellProductionDataModel>;
            return WellProCache;
        }

    }
}
