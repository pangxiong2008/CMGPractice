﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Caching;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for AddData.xaml
    /// </summary>
    public partial class AddData : Page
    {
        public AddData()
        {
            InitializeComponent();
            WellNamelistBox.SelectedIndex = 0;
            StatuslistBox.SelectedIndex = 0;
            DateCalendar.SelectedDate = DateTime.Now;
        }


        private void WellNameChange(object sender, RoutedEventArgs e)
        {
            ReadCache readCache = new ReadCache();
            SearchData searchData = new SearchData();
            List<WellProductionDataModel> viewData = new List<WellProductionDataModel>();
            viewData = readCache.ReadWellPro();
            if (viewData != null)
            {
                var dd= ((ListBoxItem)WellNamelistBox.SelectedItem).Content.ToString();
                if (viewData.Where(s => (s.WellName == ((ListBoxItem)WellNamelistBox.SelectedItem).Content.ToString() && s.Status == "ShutIn")).Any())
                {
                    WellNamelistBox.IsEnabled = false;
                    OilTextBox.IsReadOnly = true;
                    GasTextBox.IsReadOnly = true;
                    WaterTextBox.IsReadOnly = true;
                    ButtonAdd.IsEnabled = false;
                    if (Convert.ToInt32(this.OilTextBox.Text) != 0)
                    {
                        MessageBox.Show("ShutIn well OilProduced need equal Zero!");
                    }
                    if (Convert.ToInt32(this.GasTextBox.Text) != 0)
                    {
                        MessageBox.Show("ShutIn well GasProduced need equal Zero!");
                    }
                    if (Convert.ToInt32(this.WaterTextBox.Text) != 0)
                    {
                        MessageBox.Show("ShutIn well WaterProduced need equal Zero!");
                    }
                }
                if (viewData.Where(s => (s.WellName == ((ListBoxItem)WellNamelistBox.SelectedItem).Content.ToString() && s.Date== DateCalendar.SelectedDate)).Any())
                {
                        MessageBox.Show("Mutiple entry data for a well in the same day!");
                }
            }
        }

        private void ButtonAdd_Click(object sender, RoutedEventArgs e)
        {
            if (Convert.ToInt32(this.WaterTextBox.Text) < 0)
            {
                MessageBox.Show("WaterProduced need more than Zero!");
                return;
            }
            if (Convert.ToInt32(this.GasTextBox.Text) < 0)
            {
                MessageBox.Show("GasProduced need more than Zero!");
                return;
            }
            if (Convert.ToInt32(this.OilTextBox.Text) < 0)
            {
                MessageBox.Show("OilProduced need more than Zero!");
                return;
            }
            WellProductionDataModel wellData = new WellProductionDataModel();
            wellData.WellName = ((ListBoxItem)WellNamelistBox.SelectedItem).Content.ToString();
            wellData.OilProduced = Convert.ToInt32(OilTextBox.Text);
            wellData.GasProduced = Convert.ToInt32(GasTextBox.Text);
            wellData.WaterProduced = Convert.ToInt32(WaterTextBox.Text);
            wellData.Status = ((ListBoxItem)StatuslistBox.SelectedItem).Content.ToString();
            wellData.Date = DateCalendar.SelectedDate.Value;
            CreateCache createCache = new CreateCache();
            createCache.CacheWellPro();
            ObjectCache cache = MemoryCache.Default;
            CacheItemPolicy policy = new CacheItemPolicy();
            policy.AbsoluteExpiration = DateTime.Now.AddHours(1);
            var WellProCache = cache["WellProCache"] as List<WellProductionDataModel>;
            WellProCache.Add(wellData);
            cache.Set("WellProCache", WellProCache, policy);
            NavigationService.GetNavigationService(this).Navigate(new Uri("WellDetail.xaml", UriKind.Relative));
        }
    }
}
