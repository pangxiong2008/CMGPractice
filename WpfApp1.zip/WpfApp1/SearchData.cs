﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    class SearchData
    {
        public List<WellProductionDataModel>CeateData(List<WellProductionDataModel> ListScourse,string searchType)
        {
            List<WellProductionDataModel> listResult = new List<WellProductionDataModel>();

            if (ListScourse.Any())
            {
                switch (searchType)
                {
                    case "OilProduced":
                    listResult = ListScourse.OrderBy(listdata => listdata.OilProduced).ToList();
                        break;
                    case "GasProduced":
                        listResult = ListScourse.OrderBy(listdata => listdata.GasProduced).ToList();
                        break;
                    case "WaterProduced":
                        listResult = ListScourse.OrderBy(listdata => listdata.WaterProduced).ToList();
                        break;
                    case "Status":
                        listResult = ListScourse.OrderBy(listdata => listdata.Status).ToList();
                        break;
                    case "Date":
                        listResult = ListScourse.OrderBy(listdata => listdata.Date).ToList();
                        break;
                    default:
                        listResult = ListScourse.OrderBy(listdata => listdata.WellName).ToList();
                        break;
                }
               
            }
            return listResult;

        }


    }
}
