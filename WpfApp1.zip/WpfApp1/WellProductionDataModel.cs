﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    public class WellProductionDataModel
    {
        public DateTime Date { set; get; }
        public string WellName { set; get; }
        public int OilProduced { set; get; }
        public int GasProduced { set; get; }
        public int WaterProduced { set; get; }
        public string Status { set; get; }
    }
}
