﻿using log4net;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace WpfApp1
{
    public interface IData
    {
         List<WellProductionDataModel> ImportData();
    }
    /// <summary>
    /// ReadData class
    /// import data from data sources
    /// </summary>
    public  class ReadData : IData
    {
        private static log4net.ILog Log { get; } = LogManager.GetLogger(typeof(ReadData));
        /// <summary>
        /// importdata method
        /// read data from xml document
        /// </summary>
        /// <returns></returns>
        public  List<WellProductionDataModel> ImportData()
        {
            List<WellProductionDataModel> WellProModel = new List<WellProductionDataModel>();
            try
            {
                var pathEnvironment = AppDomain.CurrentDomain.BaseDirectory.Replace("bin\\Debug\\", "");
                Configuration configuration = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                AppSettingsSection appSettings = configuration.AppSettings;
                var pathConfig = appSettings.Settings["DataPath"].Value;

                var path = @Path.Combine(pathEnvironment, pathConfig);
                XDocument doc = XDocument.Load(path);
                if (doc != null)
                {
                    WellProModel = doc.Descendants("WellProduction").Select(x => new WellProductionDataModel()
                    {
                        WellName  = x.Element("WellName").Value,
                        Status  = x.Element("Status").Value,
                        WaterProduced = Convert.ToInt32(string.IsNullOrEmpty(x.Element("WaterProduced").Value) ? "0" : x.Element("WaterProduced").Value.Split(' ').First()),
                        GasProduced = Convert.ToInt32(string.IsNullOrEmpty(x.Element("GasProduced").Value) ? "0" : x.Element("GasProduced").Value.Split(' ')[0]),
                        OilProduced = Convert.ToInt32(string.IsNullOrEmpty(x.Element("OilProduced").Value) ? "0" : x.Element("OilProduced").Value.Split(' ')[0]),
                        Date = Convert.ToDateTime(string.IsNullOrEmpty(x.Element("Date").Value) ? "9999-12-31" : x.Element("Date").Value),
                    }
                    ).ToList();
                }
                else
                {
                    WellProModel = null;
                }

            }
            catch (Exception Ex)
            {
                WellProModel = null;
                Log.Error(Ex);
            }

            return WellProModel;
        }
    }
}
