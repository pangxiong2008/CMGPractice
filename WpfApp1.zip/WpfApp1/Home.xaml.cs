﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for Home.xaml
    /// </summary>
    public partial class Home : Page
    {
        public Home()
        {
            InitializeComponent();
           
        }
        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
                dlg.DefaultExt = ".xml";
                Nullable<bool> result = dlg.ShowDialog();
                if (result == true)
                {

                    string filename = dlg.FileName;
                    TextBoxFilePath.Text = filename;
                    CreateCache createCache = new CreateCache();
                    var WellData = await createCache.CacheWellPro();
                    if (WellData == null)
                    {
                       throw new Exception("Empty DataSource");
                    }
                   
                }
             }
            catch (Exception ex)
            {
                TextBoxFilePath.Text = "Empty DataSource";
            }
        }

        private void ButtonViewReport_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GetNavigationService(this).Navigate(new Uri("WellDetail.xaml", UriKind.Relative));
        }
    }


}
