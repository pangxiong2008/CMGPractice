﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for WellDetail.xaml
    /// </summary>
    public partial class WellDetail : Page
    {
        public WellDetail()
        {
            InitializeComponent();
            DataTable dt = new System.Data.DataTable();
            dt.Columns.Add("WellName", typeof(string));
            dt.Columns.Add("OilProduced", typeof(int));
            dt.Columns.Add("GasProduced", typeof(int));
            dt.Columns.Add("WaterProduced", typeof(int));
            dt.Columns.Add("Status", typeof(string));
            dt.Columns.Add("Date", typeof(DateTime));
            ReadCache readCache = new ReadCache();
            List<WellProductionDataModel> viewData = new List<WellProductionDataModel>();
            viewData=readCache.ReadWellPro();
            if (viewData !=null)
            {
                foreach(var rowData in viewData)
                {
                    DataRow row = dt.NewRow();
                    row["WellName"] = rowData.WellName;
                    row["OilProduced"] = rowData.OilProduced;
                    row["GasProduced"] = rowData.GasProduced;
                    row["WaterProduced"] = rowData.WaterProduced;
                   
                    row["Status"] = rowData.Status;
                    row["Date"] = rowData.Date;
                    dt.Rows.Add(row);
                }
            }
            dataGrid.ItemsSource = dt.DefaultView;
            dataGrid.UpdateLayout();
            dataGrid.ItemContainerGenerator.StatusChanged += ItemContainerGenerator_StatusChanged;
            dataGrid.GridLinesVisibility = DataGridGridLinesVisibility.All;
        }
        private void SordChange(object sender, RoutedEventArgs e)
        {
            ListBoxItem lbi = ((sender as ListBox).SelectedItem as ListBoxItem);
            DataTable dt = new System.Data.DataTable();
            dt.Columns.Add("WellName", typeof(string));
            dt.Columns.Add("OilProduced", typeof(int));
            dt.Columns.Add("GasProduced", typeof(int));
            dt.Columns.Add("WaterProduced", typeof(int));
            dt.Columns.Add("Status", typeof(string));
            dt.Columns.Add("Date", typeof(DateTime));
            ReadCache readCache = new ReadCache();
            SearchData searchData = new SearchData();
            List<WellProductionDataModel> viewData = new List<WellProductionDataModel>();
            viewData = readCache.ReadWellPro();
            if (viewData != null)
            {
                List<WellProductionDataModel> serarchViewData = new List<WellProductionDataModel>();
                serarchViewData = searchData.CeateData(viewData, lbi.Content.ToString());
                if (serarchViewData != null)
                {
                    foreach (var rowData in serarchViewData)
                    {
                        DataRow row = dt.NewRow();
                        row["WellName"] = rowData.WellName;
                        row["OilProduced"] = rowData.OilProduced;
                        row["GasProduced"] = rowData.GasProduced;
                        row["WaterProduced"] = rowData.WaterProduced;

                        row["Status"] = rowData.Status;
                        row["Date"] = rowData.Date;
                        dt.Rows.Add(row);
                    }
                }
            }
            dataGrid.ItemsSource = dt.DefaultView;
            if (!Window.GetWindow(dataGrid).IsVisible)
            {
                Window.GetWindow(dataGrid).Show();
            }
            dataGrid.UpdateLayout();
           
            for (int i = 0; i < this.dataGrid.Items.Count - 1; i++)
            {
                DataRowView drv = dataGrid.Items[i] as DataRowView;
                DataGridRow row = (DataGridRow)dataGrid.ItemContainerGenerator.ContainerFromIndex(i);              
                DataGridCellsPresenter presenter = GetVisualChild<DataGridCellsPresenter>(row);
                    DataGridCell cell = (DataGridCell)presenter.ItemContainerGenerator.ContainerFromIndex(4);
                    switch (drv["Status"].ToString())
                    {
                        case "Open":
                            cell.Foreground = new SolidColorBrush(Colors.Red);
                           break;
                        case "Shut-in":
                            cell.Foreground = new SolidColorBrush(Colors.Yellow);
                        row.Background= new SolidColorBrush(Colors.Gray);
                        break;
                       
                    default:
                        cell.Foreground = new SolidColorBrush(Colors.CadetBlue);
                        break;
                }
            }
            dataGrid.GridLinesVisibility = DataGridGridLinesVisibility.All;
        }
        void ItemContainerGenerator_StatusChanged(object sender, EventArgs e)
        {
            if (dataGrid.ItemContainerGenerator.Status
                == System.Windows.Controls.Primitives.GeneratorStatus.ContainersGenerated)
            {
                dataGrid.ItemContainerGenerator.StatusChanged
                    -= ItemContainerGenerator_StatusChanged;
                Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Input,
                    new Action(DelayedAction));
            }
        
    }
        void DelayedAction()
        {
            if (!Window.GetWindow(dataGrid).IsVisible)
            {
                Window.GetWindow(dataGrid).Show();
            }
            for (int i = 0; i < this.dataGrid.Items.Count - 1; i++)
            {
                DataRowView drv = dataGrid.Items[i] as DataRowView;
                DataGridRow row = (DataGridRow)dataGrid.ItemContainerGenerator.ContainerFromIndex(i);
                DataGridCellsPresenter presenter = GetVisualChild<DataGridCellsPresenter>(row);
                DataGridCell cell = (DataGridCell)presenter.ItemContainerGenerator.ContainerFromIndex(4);
                switch (drv["Status"].ToString())
                {
                    case "Open":
                        cell.Foreground = new SolidColorBrush(Colors.Red);
                        break;
                    case "Shut-in":
                        cell.Foreground = new SolidColorBrush(Colors.Yellow);
                        row.Background = new SolidColorBrush(Colors.Gray);
                        break;
                    default:
                        cell.Foreground = new SolidColorBrush(Colors.CadetBlue);
                        break;
                }
            }
        }
        //private void DataGrid_LoadingRow(object sender, DataGridRowEventArgs e)
        //{
        //    if (!Window.GetWindow(dataGrid).IsVisible)
        //    {
        //        Window.GetWindow(dataGrid).Show();
        //    }
        //    dataGrid.UpdateLayout();
        //    for (int i = 0; i < this.dataGrid.Items.Count-1; i++)
        //    {
        //        DataRowView drv = dataGrid.Items[i] as DataRowView;
        //        DataGridRow row = (DataGridRow)dataGrid.ItemContainerGenerator.ContainerFromIndex(i);
        //        if (i == 4)
        //        {
        //            DataGridCellsPresenter presenter = GetVisualChild<DataGridCellsPresenter>(row);
        //            DataGridCell cell = (DataGridCell)presenter.ItemContainerGenerator.ContainerFromIndex(1);
        //            switch (cell.ToString())
        //            {
        //                case "Open":
        //                    cell.Background = new SolidColorBrush(Colors.Red); break;
        //                case "2":
        //                    e.Row.Foreground = new SolidColorBrush(Colors.Yellow);
        //                    break;
        //                case "3":
        //                    e.Row.Foreground = new SolidColorBrush(Colors.CadetBlue);
        //                    break;
        //            }
        //        }    
        //    }  
        //}
        public static T GetVisualChild<T>(Visual parent) where T : Visual
        {
            T childContent = default(T);
            int numVisuals = VisualTreeHelper.GetChildrenCount(parent);
            for (int i = 0; i < numVisuals; i++)
            {
                Visual v = (Visual)VisualTreeHelper.GetChild(parent, i);
                childContent = v as T;
                if (childContent == null)
                {
                    childContent = GetVisualChild<T>(v);
                }
                if (childContent != null)
                {
                    break;
                }
            }

            return childContent;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //NavigationWindow wds = new NavigationWindow();
            //wds.Source = new Uri("AddData.xaml", UriKind.Relative);
            //wds.Show();
            NavigationService.GetNavigationService(this).Navigate(new Uri("AddData.xaml", UriKind.Relative));
        }
    }
}
